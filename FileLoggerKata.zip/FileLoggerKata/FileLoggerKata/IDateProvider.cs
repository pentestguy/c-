﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FileLoggerKata
{
    public interface IDateProvider
    {
        DateTime Today { get; }
    }
}
